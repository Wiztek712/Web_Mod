// Fonction pour trouver le dossier des favoris principaux
const mainFolderId = "-AsCWKV4LM_D"; // Renseignez ici l'ID du dossier des favoris principaux

// Fonction pour afficher les favoris dans la barre latérale
function displayMainBookmarks(bookmarks) {
    const mainBookmarksContainer = document.getElementById('main-bookmarks');
    mainBookmarksContainer.innerHTML = '';  // Vider le conteneur

    for (let bookmark of bookmarks) {
        if (bookmark.url) {
            const bookmarkDiv = document.createElement('div');
            bookmarkDiv.classList.add('sidebar-bookmark');
            
            const a = document.createElement('a');
            a.href = bookmark.url;
            a.title = bookmark.title;

            const img = document.createElement('img');
            img.src = `https://www.google.com/s2/favicons?sz=64&domain_url=${bookmark.url}`; // Utiliser l'icône du site
            
            //const span = document.createElement('span');
            //span.textContent = bookmark.title;

            a.appendChild(img);
            //a.appendChild(span);
            bookmarkDiv.appendChild(a);
            mainBookmarksContainer.appendChild(bookmarkDiv);
        }
    }
}

// Fonction pour afficher les autres favoris
function displayOtherBookmarks(bookmarks) {
    const container = document.getElementById('bookmark-container');
    container.innerHTML = '';  // Vider le conteneur avant d'ajouter du contenu

    // Parcourir les favoris et générer les dossiers
    function createBookmarkList(bookmarks) {
        const ul = document.createElement('ul');
        for (let bookmark of bookmarks) {
            if (bookmark.url) {
                const li = document.createElement('li');
                const a = document.createElement('a');
                a.href = bookmark.url;
                a.textContent = bookmark.title || bookmark.url;
                li.appendChild(a);
                ul.appendChild(li);
            } else if (bookmark.children) {
                // Si c'est un dossier, on le crée aussi
                const folder = document.createElement('div');
                folder.classList.add('bookmark-folder');
                const title = document.createElement('h2');
                title.textContent = bookmark.title || "Dossier sans titre";
                folder.appendChild(title);
                folder.appendChild(createBookmarkList(bookmark.children));
                container.appendChild(folder);
            }
        }
        return ul;
    }

    // Ajout des favoris au DOM
    container.appendChild(createBookmarkList(bookmarks));
}

// Fonction pour parcourir l'arbre de favoris et afficher les résultats
function displayBookmarks() {
    browser.bookmarks.getTree().then((bookmarks) => {
        const rootBookmarks = bookmarks[0].children;

        // Parcourir les dossiers pour trouver le dossier principal
        let mainBookmarks = null;
        let otherBookmarks = [];

        function findBookmarks(bookmarks) {
            for (let bookmark of bookmarks) {
                if (bookmark.id === mainFolderId) {
                    mainBookmarks = bookmark.children;
                } else if (bookmark.children) {
                    otherBookmarks.push(bookmark);
                    findBookmarks(bookmark.children);
                }
            }
        }

        findBookmarks(rootBookmarks);

        // Afficher les favoris principaux dans la barre latérale
        if (mainBookmarks) {
            displayMainBookmarks(mainBookmarks);
        }

        // Afficher les autres favoris au centre
        displayOtherBookmarks(otherBookmarks);
    });
}

// Appel de la fonction pour afficher les favoris
displayBookmarks();
